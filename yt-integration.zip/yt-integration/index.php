<?php
    //For WordPress Installs - Best kept empty
?>
